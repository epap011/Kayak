function null_func() {
}
